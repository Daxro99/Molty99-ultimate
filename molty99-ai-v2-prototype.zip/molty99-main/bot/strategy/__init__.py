# Strategy module
